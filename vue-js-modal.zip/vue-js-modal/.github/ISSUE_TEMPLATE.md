#### Problem: 

...

#### Example & screenshots:

...

I have checked stackoverflow for solutions and 100% sure that issue not in my code.
